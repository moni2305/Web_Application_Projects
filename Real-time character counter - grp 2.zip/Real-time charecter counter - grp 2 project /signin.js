const p_numEl = document.getElementById("p_num");
const totalCounterEl = document.getElementById("total-counter");
const remainingCounterEl = document.getElementById("remaining-counter");

p_numEl.addEventListener("keyup", () => {
  updateCounter();
});

updateCounter()

function updateCounter() {
  totalCounterEl.innerText = p_numEl.value.length;
  remainingCounterEl.innerText =
   p_numEl.getAttribute("maxLength") - p_numEl.value.length;
}